package com.example.ads

/**
 * Tapsell Plus configuration for Studio Taraneh only.
 * These IDs belong to the Studio Taraneh app and are intentionally kept
 * separate from the independent five-ad-management project.
 */
object TapsellConfig {
    const val APP_ID = "gpddcgcgnthsorrgsomlesospgkmardetodjogicakngbrdetccegepaonlonfbpeqboom"

    const val ZONE_INTERSTITIAL = "6abaecc83c315037c8c55b1d"
    const val ZONE_REWARDED_VIDEO = "6abaebb00a772b2b3f29c16b"
    const val ZONE_STANDARD_BANNER = "6abaec923c315037c8c55b1c"
    const val ZONE_NATIVE_VIDEO = "6abaec4169b53c3fd930618e"
    const val ZONE_PRE_ROLL_VIDEO = "6abaec013c315037c8c55b1b"

    const val INTERSTITIAL_COOLDOWN_SECONDS = 30L
}

package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.ViewGroup
import android.widget.FrameLayout
import ir.tapsell.plus.AdRequestCallback
import ir.tapsell.plus.AdShowListener
import ir.tapsell.plus.TapsellPlus
import ir.tapsell.plus.TapsellPlusBannerType
import ir.tapsell.plus.model.TapsellPlusAdModel
import ir.tapsell.plus.model.TapsellPlusErrorModel

/**
 * Advertising layer for Studio Taraneh.
 * The public surface is kept independent from the UI so existing screens
 * and layouts are not changed by this manager.
 */
class TapsellManager private constructor() {

    companion object {
        private const val TAG = "TapsellManager"

        @Volatile
        private var instance: TapsellManager? = null

        fun getInstance(): TapsellManager = instance ?: synchronized(this) {
            instance ?: TapsellManager().also { instance = it }
        }
    }

    private var isInitialized = false
    private var lastInterstitialTime = 0L

    fun initialize(context: Context) {
        if (isInitialized) return
        runCatching {
            TapsellPlus.initialize(context.applicationContext, TapsellConfig.APP_ID)
            isInitialized = true
            Log.d(TAG, "Tapsell Plus initialized")
        }.onFailure {
            Log.e(TAG, "Tapsell initialization failed", it)
        }
    }

    fun requestStandardBanner(
        activity: Activity,
        container: FrameLayout,
        onFailed: () -> Unit = {}
    ) {
        if (!isInitialized) { onFailed(); return }
        runCatching {
            TapsellPlus.requestStandardBannerAd(
                activity,
                TapsellConfig.ZONE_STANDARD_BANNER,
                TapsellPlusBannerType.BANNER_320x50,
                object : AdRequestCallback() {
                    override fun response(adModel: TapsellPlusAdModel) {
                        TapsellPlus.showStandardBannerAd(
                            activity,
                            adModel.responseId,
                            container,
                            object : AdShowListener() {
                                override fun onError(error: TapsellPlusErrorModel?) {
                                    onFailed()
                                }
                            }
                        )
                    }

                    override fun error(error: String) {
                        Log.e(TAG, "Standard banner request failed: $error")
                        onFailed()
                    }
                }
            )
        }.onFailure {
            Log.e(TAG, "Standard banner exception", it)
            onFailed()
        }
    }

    fun showInterstitial(
        activity: Activity,
        forceShow: Boolean = false,
        onClosed: () -> Unit = {}
    ) {
        if (!isInitialized) { onClosed(); return }
        val now = System.currentTimeMillis() / 1000
        if (!forceShow && now - lastInterstitialTime < TapsellConfig.INTERSTITIAL_COOLDOWN_SECONDS) {
            onClosed()
            return
        }

        runCatching {
            TapsellPlus.requestInterstitialAd(
                activity,
                TapsellConfig.ZONE_INTERSTITIAL,
                object : AdRequestCallback() {
                    override fun response(adModel: TapsellPlusAdModel) {
                        TapsellPlus.showInterstitialAd(
                            activity,
                            adModel.responseId,
                            object : AdShowListener() {
                                override fun onClosed(ad: TapsellPlusAdModel?) {
                                    lastInterstitialTime = System.currentTimeMillis() / 1000
                                    onClosed()
                                }

                                override fun onError(error: TapsellPlusErrorModel?) {
                                    onClosed()
                                }
                            }
                        )
                    }

                    override fun error(error: String) {
                        Log.e(TAG, "Interstitial request failed: $error")
                        onClosed()
                    }
                }
            )
        }.onFailure {
            Log.e(TAG, "Interstitial exception", it)
            onClosed()
        }
    }

    fun showRewardedVideo(
        activity: Activity,
        onRewarded: () -> Unit,
        onClosed: () -> Unit = {}
    ) {
        if (!isInitialized) { onClosed(); return }
        runCatching {
            TapsellPlus.requestRewardedVideoAd(
                activity,
                TapsellConfig.ZONE_REWARDED_VIDEO,
                object : AdRequestCallback() {
                    override fun response(adModel: TapsellPlusAdModel) {
                        TapsellPlus.showRewardedVideoAd(
                            activity,
                            adModel.responseId,
                            object : AdShowListener() {
                                override fun onRewarded(ad: TapsellPlusAdModel?) {
                                    onRewarded()
                                }

                                override fun onClosed(ad: TapsellPlusAdModel?) {
                                    onClosed()
                                }

                                override fun onError(error: TapsellPlusErrorModel?) {
                                    onClosed()
                                }
                            }
                        )
                    }

                    override fun error(error: String) {
                        Log.e(TAG, "Rewarded request failed: $error")
                        onClosed()
                    }
                }
            )
        }.onFailure {
            Log.e(TAG, "Rewarded exception", it)
            onClosed()
        }
    }

    /**
     * Native-video support is exposed through the legacy Tapsell SDK bundled
     * with Tapsell Plus. Reflection is used here because the native-video API
     * is not part of TapsellPlus's public facade in 2.3.2.
     *
     * This keeps the project buildable against Tapsell Plus 2.3.2 while still
     * allowing the Studio Taraneh native-video zone to be requested when the
     * underlying SDK exposes that API.
     */
    fun requestNativeVideo(
        activity: Activity,
        onAdReady: (String) -> Unit = {},
        onFailed: () -> Unit = {}
    ) {
        if (!isInitialized) { onFailed(); return }
        try {
            val tapsellClass = Class.forName("ir.tapsell.sdk.Tapsell")
            val method = tapsellClass.methods.firstOrNull {
                it.name == "requestNativeVideoAd" && it.parameterTypes.size >= 4
            } ?: run {
                Log.e(TAG, "Native video API is not exposed by the bundled SDK")
                onFailed()
                return
            }

            val parameterTypes = method.parameterTypes
            val args = arrayOfNulls<Any>(parameterTypes.size)
            args[0] = activity
            args[1] = TapsellConfig.ZONE_NATIVE_VIDEO

            for (i in 2 until parameterTypes.size) {
                val type = parameterTypes[i]
                args[i] = java.lang.reflect.Proxy.newProxyInstance(
                    type.classLoader,
                    arrayOf(type)
                ) { _, invoked, values ->
                    if (invoked.name.contains("Filled", true) || invoked.name.contains("Available", true)) {
                        val adId = values?.firstOrNull { it is String } as? String
                        if (!adId.isNullOrBlank()) onAdReady(adId)
                    } else if (invoked.name.contains("Error", true) ||
                        invoked.name.contains("NoAd", true) ||
                        invoked.name.contains("Network", true)
                    ) {
                        onFailed()
                    }
                    null
                }
            }
            method.invoke(null, *args)
        } catch (t: Throwable) {
            Log.e(TAG, "Native video request failed", t)
            onFailed()
        }
    }

    /**
     * Fills a native-video layout using the legacy Tapsell API when available.
     * The caller supplies the existing views, so this method never changes the
     * Studio Taraneh UI by itself.
     */
    fun fillNativeVideoAd(
        activity: Activity,
        adId: String,
        autoStartVideo: Boolean,
        fullscreenOnClick: Boolean,
        title: android.widget.TextView,
        description: android.widget.TextView,
        videoContainer: ViewGroup,
        logo: android.widget.ImageView,
        cta: android.widget.TextView,
        sponsored: android.widget.TextView,
        adContainer: ViewGroup?
    ): Boolean {
        return try {
            val tapsellClass = Class.forName("ir.tapsell.sdk.Tapsell")
            val method = tapsellClass.methods.firstOrNull {
                it.name == "fillNativeVideoAd" && it.parameterTypes.size >= 11
            } ?: return false
            method.invoke(
                null,
                activity,
                adId,
                autoStartVideo,
                fullscreenOnClick,
                title,
                description,
                videoContainer,
                logo,
                cta,
                sponsored,
                adContainer
            )
            true
        } catch (t: Throwable) {
            Log.e(TAG, "Native video fill failed", t)
            false
        }
    }

    /** The fifth configured ad placement: a video shown through the interstitial facade. */
    fun showPreRollVideo(
        activity: Activity,
        onCompleted: () -> Unit
    ) {
        if (!isInitialized) { onCompleted(); return }
        runCatching {
            TapsellPlus.requestInterstitialAd(
                activity,
                TapsellConfig.ZONE_PRE_ROLL_VIDEO,
                object : AdRequestCallback() {
                    override fun response(adModel: TapsellPlusAdModel) {
                        TapsellPlus.showInterstitialAd(
                            activity,
                            adModel.responseId,
                            object : AdShowListener() {
                                override fun onClosed(ad: TapsellPlusAdModel?) = onCompleted()
                                override fun onError(error: TapsellPlusErrorModel?) = onCompleted()
                            }
                        )
                    }

                    override fun error(error: String) = onCompleted()
                }
            )
        }.onFailure {
            Log.e(TAG, "Pre-roll exception", it)
            onCompleted()
        }
    }
}

package com.example.billing

import android.content.Context
import android.util.Log
import androidx.activity.result.ActivityResultRegistry
import ir.cafebazaar.poolakey.Connection
import ir.cafebazaar.poolakey.Payment
import ir.cafebazaar.poolakey.config.PaymentConfiguration
import ir.cafebazaar.poolakey.config.SecurityCheck
import ir.cafebazaar.poolakey.entity.PurchaseInfo
import ir.cafebazaar.poolakey.request.PurchaseRequest

/**
 * CafeBazaar billing layer for Studio Taraneh.
 * Uses Poolakey 2.2.0 callback APIs and does not alter the UI.
 */
class BazaarBillingManager(private val context: Context) {

    companion object {
        private const val TAG = "BazaarBilling"

        val ALL_VIP_SKUS = listOf(
            BazaarConfig.SKU_VIP_MONTHLY,
            BazaarConfig.SKU_VIP_QUARTERLY,
            BazaarConfig.SKU_VIP_YEARLY,
            BazaarConfig.SKU_VIP_LIFETIME
        )

        fun skuForPlan(planId: String): String? = when (planId) {
            "plan_month_1" -> BazaarConfig.SKU_VIP_MONTHLY
            "plan_month_3" -> BazaarConfig.SKU_VIP_QUARTERLY
            "plan_year_1" -> BazaarConfig.SKU_VIP_YEARLY
            "plan_lifetime" -> BazaarConfig.SKU_VIP_LIFETIME
            else -> null
        }
    }

    private var payment: Payment? = null
    private var connection: Connection? = null
    private var connected = false

    fun connect(
        onConnected: () -> Unit = {},
        onDisconnected: () -> Unit = {},
        onFailed: (Throwable) -> Unit = {}
    ) {
        if (connected) {
            onConnected()
            return
        }

        try {
            val config = PaymentConfiguration(
                localSecurityCheck = SecurityCheck.Enable(
                    rsaPublicKey = BazaarConfig.RSA_PUBLIC_KEY
                ),
                shouldSupportSubscription = true
            )

            val newPayment = Payment(context, config)
            payment = newPayment
            connection?.disconnect()

            connection = newPayment.connect {
                connectionSucceed {
                    connected = true
                    Log.d(TAG, "Connected to CafeBazaar")
                    onConnected()
                }
                disconnected {
                    connected = false
                    Log.d(TAG, "Disconnected from CafeBazaar")
                    onDisconnected()
                }
                connectionFailed { throwable ->
                    connected = false
                    Log.e(TAG, "CafeBazaar connection failed", throwable)
                    onFailed(throwable)
                }
            }
        } catch (t: Throwable) {
            connected = false
            Log.e(TAG, "CafeBazaar initialization failed", t)
            onFailed(t)
        }
    }

    fun disconnect() {
        runCatching { connection?.disconnect() }
        connection = null
        connected = false
    }

    fun isConnected(): Boolean = connected

    fun purchase(
        registry: ActivityResultRegistry,
        sku: String,
        onSuccess: (PurchaseInfo) -> Unit,
        onFailed: (Throwable) -> Unit,
        onCanceled: () -> Unit = {}
    ) {
        val p = payment
        if (!connected || p == null) {
            onFailed(IllegalStateException("CafeBazaar is not connected"))
            return
        }

        val request = PurchaseRequest(
            productId = sku,
            payload = "studio_taraneh_vip"
        )

        try {
            p.purchaseProduct(
                registry = registry,
                request = request
            ) {
                purchaseFlowBegan {
                    Log.d(TAG, "Bazaar purchase flow began: $sku")
                }
                failedToBeginFlow { throwable ->
                    onFailed(throwable)
                }
                purchaseSucceed { purchaseInfo ->
                    Log.d(TAG, "Purchase succeeded: ${purchaseInfo.productId}")
                    onSuccess(purchaseInfo)
                }
                purchaseCanceled {
                    onCanceled()
                }
                purchaseFailed { throwable ->
                    onFailed(throwable)
                }
            }
        } catch (t: Throwable) {
            onFailed(t)
        }
    }

    fun subscribe(
        registry: ActivityResultRegistry,
        sku: String,
        onSuccess: (PurchaseInfo) -> Unit,
        onFailed: (Throwable) -> Unit,
        onCanceled: () -> Unit = {}
    ) {
        val p = payment
        if (!connected || p == null) {
            onFailed(IllegalStateException("CafeBazaar is not connected"))
            return
        }

        val request = PurchaseRequest(
            productId = sku,
            payload = "studio_taraneh_vip"
        )

        try {
            p.subscribeProduct(
                registry = registry,
                request = request
            ) {
                purchaseFlowBegan {
                    Log.d(TAG, "Bazaar subscription flow began: $sku")
                }
                failedToBeginFlow { throwable ->
                    onFailed(throwable)
                }
                purchaseSucceed { purchaseInfo ->
                    Log.d(TAG, "Subscription succeeded: ${purchaseInfo.productId}")
                    onSuccess(purchaseInfo)
                }
                purchaseCanceled {
                    onCanceled()
                }
                purchaseFailed { throwable ->
                    onFailed(throwable)
                }
            }
        } catch (t: Throwable) {
            onFailed(t)
        }
    }

    fun restorePurchases(
        onRestored: (List<PurchaseInfo>) -> Unit,
        onFailed: (Throwable) -> Unit
    ) {
        val p = payment
        if (!connected || p == null) {
            onFailed(IllegalStateException("CafeBazaar is not connected"))
            return
        }

        queryPurchased(p, emptyList(), onRestored, onFailed)
    }

    fun checkVipStatus(onResult: (Boolean) -> Unit) {
        val p = payment
        if (!connected || p == null) {
            onResult(false)
            return
        }

        queryPurchased(
            payment = p,
            accumulated = emptyList(),
            onSuccess = { purchases ->
                onResult(purchases.any { it.productId in ALL_VIP_SKUS })
            },
            onFailed = { onResult(false) }
        )
    }

    private fun queryPurchased(
        payment: Payment,
        accumulated: List<PurchaseInfo>,
        onSuccess: (List<PurchaseInfo>) -> Unit,
        onFailed: (Throwable) -> Unit
    ) {
        try {
            payment.getPurchasedProducts {
                querySucceed { purchases ->
                    querySubscribed(payment, accumulated + purchases, onSuccess, onFailed)
                }
                queryFailed { throwable ->
                    onFailed(throwable)
                }
            }
        } catch (t: Throwable) {
            onFailed(t)
        }
    }

    private fun querySubscribed(
        payment: Payment,
        accumulated: List<PurchaseInfo>,
        onSuccess: (List<PurchaseInfo>) -> Unit,
        onFailed: (Throwable) -> Unit
    ) {
        try {
            payment.getSubscribedProducts {
                querySucceed { subscriptions ->
                    onSuccess(accumulated + subscriptions)
                }
                queryFailed { throwable ->
                    onFailed(throwable)
                }
            }
        } catch (t: Throwable) {
            onFailed(t)
        }
    }
}
